# Day 05 Homework — Regression Deep Dive

Three tasks. Each is a runnable Python file. Run with `py hw1_your_own_curve.py`,
etc. A sample `Bengaluru_House_Data_sample.csv` is included for hw2.

---

## Q1 (Easy, 10 min) — Your own curve

**What the question is asking**
Write down 12 pairs: the hour of the day and how many minutes it took you to
reach college/office at that hour (from memory or Google Maps). Fit three
polynomials — degree 1 (straight line), degree 2 (gentle curve), and degree 6
(very wiggly) — using `PolynomialFeatures`. Which degree would you trust to
predict tomorrow's commute? Give one sentence why.

**How to approach it**
Put your 12 hours in one array and the 12 travel-times in another. For each
degree, build a pipeline of three steps: `PolynomialFeatures(degree=d)` to
create the curved terms (x, x^2, x^3, ...), `StandardScaler` to keep the
features on the same scale (x^6 is much bigger than x, which breaks the fit),
and `LinearRegression` to fit the line through those terms. Fit on your 12
points, plot the curve over a smooth grid of hours, and compute the RMSE to
see how close each fit is. Then look at the three plots: degree 1 is too
stiff to capture the rush-hour hump; degree 2 bends just enough to follow the
morning-slow / midday-fast / evening-slow shape; degree 6 wiggles wildly
between points, chasing noise — that is overfitting. Trust degree 2.

**How the solution does it (in words)**
The script uses 12 sample commute points (fast early morning, slow at 8-9am
rush, fast at midday, slow at 5-6pm evening). For each degree (1, 2, 6) it
builds a `PolynomialFeatures -> StandardScaler -> LinearRegression` pipeline,
fits it, plots the curve, and prints the RMSE. The output shows degree 1 is
too rigid (misses the rush hump), degree 2 follows the real shape well, and
degree 6 overfits (wild wiggles between points). The script saves a 3-panel
chart as `commute_curve.png` and recommends degree 2: simple enough to
generalise, curved enough to be useful.

---

## Q2 (Medium, 20 min) — Bengaluru house prices

**What the question is asking**
Load the Kaggle Bengaluru house-price dataset. Keep only `total_sqft`, `bath`,
and `bhk` (parse "2 BHK" to get the number 2). Drop rows where `total_sqft` is
a range like "2100 - 2850" instead of a plain number. Remove absurd listings
(less than 300 sqft per bedroom). Compute VIF to check for multicollinearity.
Then compare three models — OLS (plain linear regression), Ridge, and Lasso —
inside a `StandardScaler` pipeline, and report the test RMSE in lakhs.

**How to approach it**
Read the CSV. Filter `total_sqft` to only rows matching a plain number (use a
regex like `\d+(\.\d+)?`), then convert to float. Extract the number from the
`size` column ("2 BHK" -> 2) with `str.extract(r"(\d+)")`. Drop any rows still
missing needed values. Filter out listings where sqft/bhk is under 300 (data
errors). Split into train/test. Compute VIF by hand: for each feature, regress
it on all the others and compute 1/(1-R^2); values above 5-10 mean the features
are redundant. Then for each model, build `make_pipeline(StandardScaler, model)`,
fit, predict on the test set, and compute RMSE. Ridge shrinks weights smoothly;
Lasso pushes weak ones to exactly zero — you will see it drop the redundant
feature that VIF flagged.

**How the solution does it (in words)**
The script loads the included 40-row sample (or the full Kaggle CSV if you swap
the path). It cleans `total_sqft` (drops 3 range-rows), parses `bhk` from the
`size` column, removes absurd listings, and splits 80/20. VIF shows `bath` and
`bhk` are highly collinear (they move together — more bedrooms usually means
more bathrooms). All three models report a test RMSE around 16 lakhs. Lasso
stands out: it sets `bhk`'s weight to exactly 0, keeping only `total_sqft` and
`bath` — automatic feature selection, exactly the Day 05 lesson. Replace the
sample CSV with the full Kaggle dataset for realistic numbers.

---

## Q3 (Stretch, job hunt) — Kaggle submission + LinkedIn

**What the question is asking**
Submit a `LassoCV` pipeline to the Kaggle "House Prices: Advanced Regression
Techniques" competition. Log-transform the target (SalePrice) before fitting.
Post 3 lines on LinkedIn: what you built, your RMSE, one thing that surprised
you. Tag it #100DaysOfML.

**How to approach it**
Download `train.csv` and `test.csv` from the Kaggle competition page. The
target is `SalePrice`, which is right-skewed (a few very expensive houses), so
take `np.log(SalePrice)` — this makes the residuals symmetric and the errors
multiplicative, which is what the competition's RMSE-on-log score rewards.
Separate numeric and categorical columns. Fill missing numeric values with 0
and one-hot encode the categoricals (`pd.get_dummies`). Build a pipeline of
`StandardScaler` + `LassoCV` (LassoCV tries many alpha values with 5-fold
cross-validation and picks the best automatically). Fit, evaluate on a hold-out
set, then refit on all the training data, predict on the test set,
exponentiate the predictions back to dollars (undo the log), and save a
`submission.csv` with Id and SalePrice. Count how many features Lasso zeroed
out — that is the "one thing that surprised you" for LinkedIn.

**How the solution does it (in words)**
The script generates a small synthetic Ames-like dataset (so it runs offline)
with numeric and categorical columns, a skewed price, and missing values. It
log-transforms the target, fills missing numerics with 0, one-hot encodes the
categoricals, splits 80/20, and fits `StandardScaler + LassoCV`. LassoCV picks
alpha = 0.008 by cross-validation, keeps 5 of 10 features (zeroing out the 5
weak ones — automatic feature selection), and achieves an RMSE of 0.155 on
the log-price hold-out. It then refits on all data, predicts, and exponentiates
back to dollar prices. To run on the real Kaggle data: set `USE_REAL_DATA =
True`, download `train.csv` and `test.csv` from the competition page into this
folder, and run again — it will produce a `submission.csv` ready to upload.
