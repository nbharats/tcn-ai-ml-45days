"""Homework 3 (Stretch, job hunt): Kaggle House Prices submission + LinkedIn.

Goal: build a LassoCV pipeline for the Kaggle "House Prices: Advanced Regression
Techniques" competition. The key steps are:
  - log-transform the target (SalePrice) so the errors are multiplicative, not
    additive — this is standard for house-price prediction and what the
    competition's RMSE-on-log scale rewards.
  - one-hot encode the categorical columns, fill missing values with 0 / mode
  - fit LassoCV (which picks the best alpha by cross-validation) inside a
    StandardScaler pipeline
  - predict on the test set, exponentiate the predictions back, and save a
    submission.csv ready to upload to Kaggle

A small synthetic dataset is generated below so the script runs out of the box.
To use the REAL Kaggle data:
  1. Download train.csv and test.csv from
     https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques
  2. Set USE_REAL_DATA = True and put the CSVs in this folder.

Run:  py hw3_kaggle_lasso.py
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

SEED = 42
USE_REAL_DATA = False     # <- set True after downloading the Kaggle CSVs


def make_sample_data(n=600, seed=42):
    """A tiny synthetic Ames-like dataset so the pipeline runs offline.

    Has a mix of numeric and categorical columns, a skewed price, and missing
    values — the same messiness the real dataset has, just smaller.
    """
    rng = np.random.default_rng(seed)
    grlivarea = rng.integers(800, 4000, n)
    bedrooms = rng.integers(2, 6, n)
    yearbuilt = rng.integers(1950, 2020, n)
    neighborhood = rng.choice(["NAmes", "CollgCr", "OldTown", "Somerst"], n)
    quality = rng.choice(["Po", "Fa", "TA", "Gd", "Ex"], n, p=[.05, .15, .4, .3, .1])

    # True price (log-normal, like real house prices)
    log_price = (12.0
                 + 0.0004 * grlivarea
                 + 0.15 * bedrooms
                 + 0.002 * (yearbuilt - 1950)
                 + rng.normal(0, 0.15, n))
    saleprice = np.exp(log_price)
    df = pd.DataFrame({
        "GrLivArea": grlivarea, "BedroomAbvGr": bedrooms, "YearBuilt": yearbuilt,
        "Neighborhood": neighborhood, "OverallQual_cat": quality,
        "SalePrice": saleprice.round(0),
    })
    # sprinkle a few missing values
    df.loc[rng.choice(n, 20, replace=False), "YearBuilt"] = np.nan
    return df


def build_features(df, numeric_cols, cat_cols):
    """Fill missing numeric with 0, one-hot encode categoricals, return X."""
    X = df[numeric_cols + cat_cols].copy()
    for c in numeric_cols:
        X[c] = X[c].fillna(0)
    X = pd.get_dummies(X, columns=cat_cols, drop_first=True, dtype=float)
    return X


def main():
    if USE_REAL_DATA:
        train = pd.read_csv("train.csv")
        numeric_cols = ["GrLivArea", "BedroomAbvGr", "YearBuilt",
                        "TotalBsmtSF", "FullBath", "GarageArea"]
        cat_cols = ["Neighborhood", "OverallQual", "ExterQual", "KitchenQual"]
    else:
        train = make_sample_data()
        numeric_cols = ["GrLivArea", "BedroomAbvGr", "YearBuilt"]
        cat_cols = ["Neighborhood", "OverallQual_cat"]

    y = np.log(train["SalePrice"])          # <- log-transform the target
    X = build_features(train, numeric_cols, cat_cols)

    # Hold out 20% to measure performance before making the submission.
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=SEED)

    # --- LassoCV pipeline: scaler + Lasso with auto-tuned alpha ---------------
    model = make_pipeline(
        StandardScaler(),
        LassoCV(cv=5, random_state=SEED, max_iter=50000),
    ).fit(X_tr, y_tr)

    # Evaluate on the hold-out set (RMSE on the LOG price, like Kaggle scores).
    rmse_log = mean_squared_error(y_te, model.predict(X_te)) ** 0.5
    alpha = model[-1].alpha_
    print(f"best alpha (LassoCV): {alpha:.5f}")
    print(f"hold-out RMSE (log price): {rmse_log:.4f}")

    # How many features did Lasso keep (non-zero weights)?
    coefs = model[-1].coef_
    n_kept = (coefs != 0).sum()
    print(f"features kept by Lasso: {n_kept} / {len(coefs)}  "
          f"(Lasso killed {(coefs == 0).sum()} weak ones)")

    # --- make a submission-style prediction ---------------------------------
    # Refit on ALL the training data, predict, exponentiate back to dollars.
    final = make_pipeline(
        StandardScaler(),
        LassoCV(cv=5, random_state=SEED, max_iter=50000),
    ).fit(X, y)

    if USE_REAL_DATA:
        test = pd.read_csv("test.csv")
        X_submit = build_features(test, numeric_cols, cat_cols)
        # Align columns (Kaggle test set may miss some dummies)
        X_submit = X_submit.reindex(columns=X.columns, fill_value=0)
        preds = np.exp(final.predict(X_submit))
        out = pd.DataFrame({"Id": test["Id"], "SalePrice": preds})
        out.to_csv("submission.csv", index=False)
        print("\nsaved submission.csv — upload to Kaggle!")
    else:
        # Demo on the hold-out set: show predicted vs actual prices
        preds = np.exp(final.predict(X_te))
        actual = np.exp(y_te)
        print(f"\nSample predictions (on hold-out, dollars):")
        for i in range(5):
            print(f"  predicted {preds[i]:>12,.0f}   actual {actual.iloc[i]:>12,.0f}")
        print("\nWith real Kaggle data: set USE_REAL_DATA = True, download train.csv")
        print("and test.csv, then run again to generate submission.csv.")


if __name__ == "__main__":
    main()
