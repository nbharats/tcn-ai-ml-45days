"""Homework 1 (Easy, ~10 min): Your own curve.

Goal: write down 12 (hour of day, minutes to reach college/office) pairs from
memory or Google Maps. Fit three polynomials — degree 1 (a line), degree 2
(a gentle curve), and degree 6 (a very wiggly curve) — using PolynomialFeatures.
Which degree would you trust for predicting tomorrow's commute? One sentence why.

A sample of 12 points is included so the script runs. Replace `hours` and
`minutes` with your own 12 numbers to make it personal.

Run:  py hw1_your_own_curve.py
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error

# --- 12 (hour of day, minutes to reach office) pairs -------------------------
# Replace with your real data.  Sample reflects typical commute patterns:
# fast early morning, slow at rush hour, faster midday, slow evening.
hours = np.array([ 7.0,  7.5,  8.0,  8.5,  9.0, 12.0, 13.0, 16.0, 17.0, 18.0, 19.0, 21.0])
minutes = np.array([20,   25,   45,   55,   50,  18,   17,   22,   40,   58,   50,  25])

# --- fit three degrees -------------------------------------------------------
degrees = [1, 2, 6]
fig, axes = plt.subplots(1, 3, figsize=(14, 4))
x_grid = np.linspace(hours.min() - 0.5, hours.max() + 0.5, 200)[:, None]

for ax, d in zip(axes, degrees):
    # Pipeline: make polynomial features -> standardise -> fit a line.
    model = make_pipeline(
        PolynomialFeatures(degree=d, include_bias=False),
        StandardScaler(),
        LinearRegression(),
    ).fit(hours[:, None], minutes)
    pred = model.predict(hours[:, None])
    rmse = mean_squared_error(minutes, pred) ** 0.5

    ax.scatter(hours, minutes, color="tab:blue", zorder=3, label="your data")
    ax.plot(x_grid, model.predict(x_grid), color="tab:orange", lw=2)
    ax.set_title(f"degree {d}  (RMSE {rmse:.1f} min)")
    ax.set_xlabel("hour of day")
    ax.set_ylabel("minutes to reach")
    ax.set_ylim(0, max(minutes) + 15)

plt.tight_layout()
plt.savefig("commute_curve.png", dpi=150)
print("saved commute_curve.png")
plt.show()

# --- which degree to trust? --------------------------------------------------
print("\nWhich degree would I trust for tomorrow's commute?")
print("  degree 1: too rigid, cannot capture the morning/evening rush hump.")
print("  degree 2: bends gently, follows the morning-slow / midday-fast shape.")
print("  degree 6: wiggles wildly between data points — overfit, unreliable.")
print("-> degree 2: simple enough to generalise, curved enough to be useful.")
