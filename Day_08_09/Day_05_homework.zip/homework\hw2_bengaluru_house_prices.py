"""Homework 2 (Medium, ~20 min): Bengaluru house prices.

Goal: take the messy Kaggle Bengaluru house-price dataset and clean it, then
compare three regression models. Specifically:
  - keep only `total_sqft`, `bath`, and `bhk` (parse "2 BHK" -> 2)
  - drop rows where total_sqft is a range like "2100 - 2850" (not a plain number)
  - remove absurd listings (less than 300 sqft per bedroom)
  - compute VIF to check for multicollinearity
  - fit OLS vs Ridge vs Lasso inside a scaled pipeline, report test RMSE in lakhs

A 40-row sample `Bengaluru_House_Data_sample.csv` is included so the script runs
without downloading from Kaggle. For the real thing, download
`Bengaluru_House_Data.csv` from Kaggle (amitabhajoy/bengaluru-house-price-data)
and swap the CSV path below.

Run:  py hw2_bengaluru_house_prices.py
"""

import re
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, RidgeCV, LassoCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

SEED = 42
CSV = "Bengaluru_House_Data_sample.csv"     # swap with the full Kaggle CSV


def vif_by_hand(df):
    """VIF = 1/(1 - R^2).  For each column, regress it on all the others."""
    out = {}
    for col in df.columns:
        others = df.drop(columns=col)
        r2 = LinearRegression().fit(others, df[col]).score(others, df[col])
        out[col] = 1 / (1 - r2 + 1e-12)     # tiny epsilon guards R^2 == 1
    return pd.Series(out).sort_values(ascending=False)


def main():
    df = pd.read_csv(CSV)
    print("loaded", len(df), "rows")

    # --- clean total_sqft: keep only rows that are a plain number -------------
    # Drops ranges like "2100 - 2850" and text entries.
    df = df[df["total_sqft"].astype(str).str.fullmatch(r"\d+(\.\d+)?")].copy()
    df["total_sqft"] = df["total_sqft"].astype(float)

    # --- parse bhk from "2 BHK" -> 2 ------------------------------------------
    df["bhk"] = df["size"].astype(str).str.extract(r"(\d+)").astype(float)

    # --- drop rows missing any of our needed columns --------------------------
    df = df.dropna(subset=["total_sqft", "bath", "bhk", "price"])

    # --- remove absurd listings: less than 300 sqft per bedroom ---------------
    # (a 2 BHK in 400 sqft is almost certainly a data error)
    df = df[(df["total_sqft"] / df["bhk"]) > 300]

    feats = ["total_sqft", "bath", "bhk"]
    X, y = df[feats], df["price"]            # price is in lakhs
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=SEED)
    print("after cleaning:", len(df), "rows | features:", feats)

    # --- VIF: is there multicollinearity? -------------------------------------
    print("\nVIF (Variance Inflation Factor):")
    print(vif_by_hand(X_tr).round(2))
    print("  (VIF > 5 = warning, > 10 = fix it. bath & bhk are correlated, as expected.)")

    # --- compare three models in a scaled pipeline ----------------------------
    models = {
        "OLS"   : LinearRegression(),
        "Ridge"  : RidgeCV(alphas=np.logspace(-3, 3, 25)),
        "Lasso"  : LassoCV(cv=5, random_state=SEED, max_iter=20000),
    }
    print("\nModel comparison (test RMSE in lakhs):")
    for name, est in models.items():
        m = make_pipeline(StandardScaler(), est).fit(X_tr, y_tr)
        rmse = mean_squared_error(y_te, m.predict(X_te)) ** 0.5
        print(f"  {name:6s} test RMSE = {rmse:.1f} lakh")
        # Show the learned weights (on the scaled features, so they are comparable)
        coefs = m[-1].coef_
        print(f"         weights (scaled) = {dict(zip(feats, np.round(coefs, 3)))}")


if __name__ == "__main__":
    main()
